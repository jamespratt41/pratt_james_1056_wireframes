console.log("javascript linked up")
